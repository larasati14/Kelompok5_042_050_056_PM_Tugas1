import 'package:flutter/material.dart';

void main() {
  runApp(const IAmSleepApp()); // Menjalankan aplikasi Flutter
}

class IAmSleepApp extends StatelessWidget {
  const IAmSleepApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFFFAF2D), // Warna latar belakang utama aplikasi (oranye lembut)
        brightness: Brightness.light, // Tema terang untuk UI
      ),
      debugShowCheckedModeBanner: false, // Menghilangkan banner debug pada aplikasi
      home: const SleepScreen(), // Halaman utama aplikasi
    );
  }
}

// Widget utama untuk layar "SleepScreen"
class SleepScreen extends StatefulWidget {
  const SleepScreen({super.key});

  @override
  State<SleepScreen> createState() => _SleepScreenState();
}

class _SleepScreenState extends State<SleepScreen> {
  final TextEditingController _moodController = TextEditingController(); // Controller untuk input mood

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "I Am Sleep",
          style: TextStyle(fontWeight: FontWeight.bold), // Membuat teks judul menjadi bold
        ),
        backgroundColor: const Color(0xFFFF7449), // Warna AppBar oranye gelap agar kontras dengan background
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center, // Mengatur elemen agar berada di tengah layar
          children: [
            // Gambar utama yang merepresentasikan tema tidur
            Image.asset(
              'assets/sleep.png', // Gambar harus ada di folder "assets"
              width: 200, // Lebar gambar diatur agar sesuai
            ),
            const SizedBox(height: 20), // Memberikan jarak antara gambar dan teks

            // Kontainer untuk menampilkan kutipan tentang tidur
            Container(
              padding: const EdgeInsets.all(16), // Padding dalam kontainer
              margin: const EdgeInsets.symmetric(horizontal: 20), // Memberikan margin di sisi kiri dan kanan
              decoration: BoxDecoration(
                color: const Color(0xFFFFC19F), // Warna latar belakang kontainer oranye pastel
                borderRadius: BorderRadius.circular(10), // Membuat sudut kontainer melengkung
              ),
              child: const Text(
                "Tidur adalah seni mengistirahatkan pikiran tanpa batas.",
                style: TextStyle(
                  fontSize: 16, 
                  fontWeight: FontWeight.bold,
                  color: Colors.black, // Warna teks hitam agar lebih jelas dibaca
                ),
                textAlign: TextAlign.center, // Teks diatur agar berada di tengah
              ),
            ),
            const SizedBox(height: 20), // Jarak antara kutipan dan input mood

            // Kotak Input Mood
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), // Padding dalam kontainer
              margin: const EdgeInsets.symmetric(horizontal: 20), // Memberikan jarak dari sisi kiri dan kanan
              decoration: BoxDecoration(
                color: const Color(0xFFFFC19F), // Warna latar belakang kontainer oranye pastel (sama seperti sebelumnya)
                borderRadius: BorderRadius.circular(10), // Membuat sudut melengkung agar tampak lebih lembut
              ),
              child: TextField(
                controller: _moodController, // Controller untuk menangani input mood pengguna
                decoration: const InputDecoration(
                  border: InputBorder.none, // Menghilangkan border agar lebih estetik
                  hintText: "Mood hari ini:", // Placeholder input
                ),
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center, // Teks input berada di tengah
              ),
            ),
            const SizedBox(height: 20), // Jarak antara input dan tombol

            // Row untuk dua tombol: Bangun Dulu & Lanjut Tidur
            Row(
              mainAxisAlignment: MainAxisAlignment.center, // Posisi tombol berada di tengah
              children: [
                ElevatedButton(
                  onPressed: () {}, // Fungsi ketika tombol diklik
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white, // Warna tombol putih agar kontras dengan latar belakang
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12), // Ukuran padding tombol
                  ),
                  child: const Text(
                    "Bangun Dulu ☀️",
                    style: TextStyle(color: Colors.black), // Warna teks hitam agar terbaca jelas
                  ),
                ),
                const SizedBox(width: 10), // Memberikan jarak antara dua tombol
                ElevatedButton(
                  onPressed: () {}, // Fungsi ketika tombol diklik
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white, // Warna tombol putih
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12), // Ukuran padding tombol
                  ),
                  child: const Text(
                    "Lanjut Tidur 🛌",
                    style: TextStyle(color: Colors.black), // Warna teks hitam
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
