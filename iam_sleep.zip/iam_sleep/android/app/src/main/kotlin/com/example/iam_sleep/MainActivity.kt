package com.example.iam_sleep

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
